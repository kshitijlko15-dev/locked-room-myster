# The Locked Room Mystery

A 60-second animated detective short, built with [Remotion](https://www.remotion.dev/) (React for video). Original flat-vector cartoon characters, backgrounds, and props — no external assets, no stock footage.

- **Duration:** exactly 60 seconds
- **Resolution:** 1920×1080
- **Frame rate:** 30 fps (1800 frames total)
- **Style:** flat-vector noir cartoon — deep desaturated blues and charcoal, one warm amber accent (the desk lamp), one cool accent (the rainy window). Chosen because a locked-room mystery runs on mood and restraint rather than busy detail; see the comment at the top of `src/theme.ts` for the full reasoning.
- **Story:** does not reveal who or what caused the three clues — it ends on the detective's reaction, as a cliffhanger.

## ⚠️ Two things this project assumes, since neither was available when it was built

1. **Narration text.** No narration script was actually present in the conversation this was built from, so `src/narration.ts` currently holds an **original placeholder script** written to fit the title. Swap in your real lines there — full instructions are in the comment at the top of that file.
2. **A GitHub repository.** This was built as a standalone project folder, not pushed into an existing repo, because no repository was connected. See "Getting this onto GitHub" below.

Everything else — the six animated scenes, camera moves, transitions, and the 1800-frame/1920×1080/30fps composition — is a complete, working project.

## What's animated

| Element | Where it lives | What it does |
|---|---|---|
| **Detective** (Inspector Maren Cole) | `src/components/Detective.tsx` | Walk-cycle on entry, idle bob, kneeling pose, subtle head tilt |
| **Study** (background) | `src/components/StudyBackground.tsx` | Bookshelf, desk, rug, lamp glow, animated rain through the window |
| **Broken bowl** | `src/components/BrokenBowl.tsx` | Shattered into six shards with a sweeping light glint |
| **Water puddle** | `src/components/WaterPuddle.tsx` | Looping expanding ripple rings, lamp reflection |
| **Fish photograph** | `src/components/FishPhotograph.tsx` | Framed line-art, slight shimmer as the camera pushes in |

Each of the six scenes (`src/scenes/`) wraps its content in `<Camera>` (`src/components/Camera.tsx`) for a distinct, eased pan/push, and crossfades into the next scene via `getEdgeFade` in `src/utils.ts` — a short fade-in/fade-out on every `Sequence` boundary, which is what gives the cinematic-transition feel without adding an extra dependency.

## Project structure

```
locked-room-mystery/
├── src/
│   ├── index.ts              # Remotion entry point
│   ├── Root.tsx               # Registers the 1920x1080/30fps/60s composition
│   ├── MysteryVideo.tsx       # Assembles the 6 scenes + optional audio
│   ├── narration.ts           # ⭐ script + timing — edit this to resync
│   ├── theme.ts                # Color palette, fonts, video constants
│   ├── utils.ts                # Camera-move and crossfade helpers
│   ├── components/             # Reusable characters, props, camera, captions
│   └── scenes/                 # Scene1Establishing … Scene6Cliffhanger
├── public/audio/README.txt     # How to add your narration recording
├── package.json
├── tsconfig.json
└── remotion.config.ts
```

## Setup

This sandbox had no network access, so dependencies could **not** be installed or build-checked here — the code was written carefully against Remotion's standard APIs, but you'll want to run the steps below yourself (locally, or in a cloud environment — see the Android section).

```bash
npm install
```

## Preview (browser-based)

```bash
npm start
```

This opens **Remotion Studio**, a local dev server with a live browser preview — drag the playhead, scrub frame-by-frame, and it hot-reloads whenever you edit a scene or `narration.ts`.

## Render the final MP4

```bash
npm run render
```

Output lands at `out/locked-room-mystery.mp4` (1920×1080, 30fps, 60s). Remotion renders by driving a headless Chromium browser frame-by-frame and stitching the result with ffmpeg (both installed automatically by Remotion) — so "browser-based rendering" is how it works by default, no extra config needed.

## Adding your narration audio

See `public/audio/README.txt` for the full steps. Short version: drop `narration.mp3` into `public/audio/`, flip `AUDIO_ENABLED` to `true` in `src/MysteryVideo.tsx`, and re-check the per-line timing in `src/narration.ts` against your actual recording.

## Changing the total length

The composition's fixed duration lives in `src/theme.ts` (`video.durationInSeconds`). If your real narration isn't 60 seconds:

1. Update `video.durationInSeconds` in `src/theme.ts`.
2. Update the `startSeconds`/`endSeconds` on each line in `src/narration.ts` so they still add up to the new total (`Root.tsx` will warn in the console if they don't match).

## Getting this onto GitHub

No repository was connected here, so this wasn't pushed anywhere — you'll get a zip of the project instead. To put it in a repo of your own:

```bash
cd locked-room-mystery
git init
git add .
git commit -m "Initial commit: The Locked Room Mystery"
git branch -M main
git remote add origin https://github.com/<your-username>/<your-repo>.git
git push -u origin main
```

(Or create the empty repo first on github.com, then follow the "push an existing repository" instructions it shows you.)

## Previewing and exporting the MP4 using only an Android phone

Remotion's render step needs Node.js and a real headless-Chromium instance, which Android doesn't provide on its own — so the practical path is to run the project in a **free browser-based cloud dev environment**, all from your phone's browser:

1. **Get the code onto GitHub.** Either:
   - Upload this project's files through github.com's "Add file → Upload files" on a new repo (works in Chrome on Android, drag in the whole unzipped folder or files in batches), or
   - If you have access to any computer briefly, run the `git push` commands above once.

2. **Open a Codespace.** On your repo's GitHub page (in your phone's browser), tap **Code → Codespaces → Create codespace on main**. This gives you a full VS Code environment with a terminal, running in the cloud — you interact with it entirely through the browser, nothing installs on your phone.

3. **In the Codespace terminal, run:**
   ```bash
   npm install
   npm start
   ```
   Codespaces will prompt you to open the forwarded port in your browser — that's **Remotion Studio**, your live preview, playable right there on your phone.

4. **To export the MP4, run:**
   ```bash
   npm run render
   ```
   When it finishes, find `out/locked-room-mystery.mp4` in the Codespace's file explorer (left sidebar), tap it, and use the **Download** option to save it to your phone.

5. Codespaces' free tier (60 core-hours/month as of this writing) is more than enough for occasional previews and renders of a 60-second video — just remember to stop the Codespace when you're done (it will also auto-stop after a period of inactivity).

This same workflow is also where you'd do step 5 above ("Adding your narration audio") — use the Codespace's file explorer to upload `narration.mp3` directly into `public/audio/` from your phone's camera roll or files app.
