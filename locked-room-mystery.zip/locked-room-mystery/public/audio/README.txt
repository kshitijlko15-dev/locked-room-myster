HOW TO ADD YOUR NARRATION AUDIO
================================

1. Record or export your narration as a single audio file.
   Supported formats: .mp3 or .wav (mp3 is smaller and recommended).

2. Name it exactly:
     narration.mp3
   (or narration.wav — if you use .wav, update the filename in
   src/MysteryVideo.tsx where it says staticFile('audio/narration.mp3'))

3. Put the file in this folder, so the path is:
     public/audio/narration.mp3

4. Open src/MysteryVideo.tsx and change:
     const AUDIO_ENABLED = false;
   to:
     const AUDIO_ENABLED = true;

5. (Recommended) Re-check the timing in src/narration.ts:
   - Play your audio file and note, in seconds, where each line
     actually starts and ends.
   - Update the startSeconds / endSeconds for each entry in
     narrationLines to match.
   - The six scenes will automatically re-time themselves to fit,
     since they all read their duration from narration.ts.

6. If your total narration is shorter or longer than 60 seconds,
   see "Changing the total length" in the project's README.md.

That's it — reload the preview (src/MysteryVideo.tsx is watched
automatically by `npx remotion studio`) and you'll hear your voice
synced to the animation.
