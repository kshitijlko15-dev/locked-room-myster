import {Config} from '@remotion/cli/config';

// Browser-based rendering: Remotion always renders frames using a headless
// Chromium instance and stitches them with ffmpeg, which is bundled
// automatically — no extra setup needed.
Config.setVideoImageFormat('jpeg');
Config.setOverwriteOutput(true);
Config.setConcurrency(1);

export {};
