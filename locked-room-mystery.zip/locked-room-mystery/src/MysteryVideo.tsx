import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile} from 'remotion';
import {sceneTimings} from './narration';
import {colors} from './theme';
import {Scene1Establishing} from './scenes/Scene1Establishing';
import {Scene2DetectiveArrives} from './scenes/Scene2DetectiveArrives';
import {Scene3BrokenBowl} from './scenes/Scene3BrokenBowl';
import {Scene4WaterPuddle} from './scenes/Scene4WaterPuddle';
import {Scene5FishPhotograph} from './scenes/Scene5FishPhotograph';
import {Scene6Cliffhanger} from './scenes/Scene6Cliffhanger';

// Set to true once you've added public/audio/narration.mp3 — see
// public/audio/README.txt. Left off by default so Studio/rendering
// never errors out over a missing file on a fresh checkout.
const AUDIO_ENABLED = false;

// Set to false once you have real narration audio playing and no
// longer want the burned-in subtitles. On by default so the sync
// between scenes and script is visible even with audio off.
const SHOW_CAPTIONS = true;

const sceneComponents = [
	Scene1Establishing,
	Scene2DetectiveArrives,
	Scene3BrokenBowl,
	Scene4WaterPuddle,
	Scene5FishPhotograph,
	Scene6Cliffhanger,
];

export const MysteryVideo: React.FC = () => {
	return (
		<AbsoluteFill style={{backgroundColor: colors.black}}>
			{sceneTimings.map((scene, i) => {
				const SceneComponent = sceneComponents[i];
				return (
					<Sequence
						key={scene.id}
						from={scene.from}
						durationInFrames={scene.durationInFrames}
						name={scene.id}
					>
						<SceneComponent
							durationInFrames={scene.durationInFrames}
							captionText={SHOW_CAPTIONS ? scene.text : ''}
						/>
					</Sequence>
				);
			})}

			{AUDIO_ENABLED && <Audio src={staticFile('audio/narration.mp3')} />}
		</AbsoluteFill>
	);
};
