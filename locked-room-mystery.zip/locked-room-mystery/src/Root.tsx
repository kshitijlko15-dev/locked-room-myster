import React from 'react';
import {Composition} from 'remotion';
import {MysteryVideo} from './MysteryVideo';
import {video, video_durationInFrames} from './theme';
import {totalDurationInFrames} from './narration';

// Sanity check during development: if someone edits narration.ts so the
// scene durations no longer add up to a full 60s, Studio will still play
// the fixed 1800-frame composition below — this just flags the mismatch
// in the console rather than silently drifting out of sync.
if (totalDurationInFrames !== video_durationInFrames) {
	// eslint-disable-next-line no-console
	console.warn(
		`narration.ts scene durations sum to ${totalDurationInFrames} frames, ` +
			`not ${video_durationInFrames} (60s @ ${video.fps}fps). ` +
			'See "Changing the total length" in README.md.'
	);
}

export const RemotionRoot: React.FC = () => {
	return (
		<Composition
			id="LockedRoomMystery"
			component={MysteryVideo}
			durationInFrames={video_durationInFrames}
			fps={video.fps}
			width={video.width}
			height={video.height}
		/>
	);
};
