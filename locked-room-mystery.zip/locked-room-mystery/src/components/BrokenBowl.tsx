import React from 'react';
import {useCurrentFrame, interpolate} from 'remotion';
import {colors} from '../theme';

type BrokenBowlProps = {
	x: number;
	y: number;
	scale?: number;
};

/**
 * A porcelain bowl, shattered into irregular shards scattered around
 * where it fell. A soft glint sweeps across the largest shard to
 * catch the eye without any extra motion.
 */
export const BrokenBowl: React.FC<BrokenBowlProps> = ({x, y, scale = 1}) => {
	const frame = useCurrentFrame();
	const glint = interpolate(frame % 90, [0, 20, 40, 90], [0, 0.9, 0, 0], {
		extrapolateLeft: 'clamp',
		extrapolateRight: 'clamp',
	});

	const shards: Array<{d: string; rotate: number; tx: number; ty: number}> = [
		{d: 'M 0 0 L 70 10 L 55 60 L -5 50 Z', rotate: -8, tx: -60, ty: -10},
		{d: 'M 0 0 L 50 -30 L 80 15 L 20 35 Z', rotate: 12, tx: 20, ty: -5},
		{d: 'M 0 0 L 40 20 L 10 55 L -25 30 Z', rotate: -20, tx: 70, ty: 20},
		{d: 'M 0 0 L 30 -10 L 45 25 L 5 35 Z', rotate: 30, tx: -110, ty: 25},
		{d: 'M 0 0 L 22 -18 L 38 6 L 10 22 Z', rotate: -45, tx: 100, ty: -20},
		{d: 'M 0 0 L 18 10 L 2 28 L -14 10 Z', rotate: 60, tx: -20, ty: 45},
	];

	return (
		<g transform={`translate(${x}, ${y}) scale(${scale})`}>
			<ellipse cx="0" cy="40" rx="150" ry="22" fill={colors.black} opacity={0.3} />
			{shards.map((shard, i) => (
				<g
					key={i}
					transform={`translate(${shard.tx}, ${shard.ty}) rotate(${shard.rotate})`}
				>
					<path
						d={shard.d}
						fill={colors.paper}
						stroke={colors.paperShadow}
						strokeWidth={2}
					/>
					{i === 0 && (
						<path
							d={shard.d}
							fill={colors.waterHighlight}
							opacity={glint * 0.5}
						/>
					)}
				</g>
			))}
		</g>
	);
};
