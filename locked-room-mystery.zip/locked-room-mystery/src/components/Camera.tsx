import React from 'react';
import {useCurrentFrame} from 'remotion';
import {getCameraTransform, CameraMoveConfig} from '../utils';

type CameraProps = CameraMoveConfig & {
	durationInFrames: number;
	children: React.ReactNode;
};

/**
 * Wraps scene content and applies a slow, eased Ken Burns-style
 * push/pan over the scene's own local timeline. Use one per scene so
 * each beat gets its own deliberate camera move rather than a single
 * motion dragged across the whole video.
 */
export const Camera: React.FC<CameraProps> = ({
	durationInFrames,
	children,
	...moveConfig
}) => {
	const frame = useCurrentFrame();
	const transform = getCameraTransform(frame, durationInFrames, moveConfig);

	return (
		<div style={{width: '100%', height: '100%', transform, transformOrigin: '50% 50%'}}>
			{children}
		</div>
	);
};
