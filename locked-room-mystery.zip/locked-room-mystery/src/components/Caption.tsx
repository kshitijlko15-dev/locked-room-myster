import React from 'react';
import {fonts} from '../theme';

type CaptionProps = {
	text: string;
	opacity: number;
};

/**
 * Simple subtitle bar. Useful while you're previewing before you've
 * added real narration audio (see SHOW_CAPTIONS in MysteryVideo.tsx),
 * and doubles as accessible burned-in captions if you keep it on.
 */
export const Caption: React.FC<CaptionProps> = ({text, opacity}) => {
	if (!text) {
		return null;
	}

	return (
		<div
			style={{
				position: 'absolute',
				left: 0,
				right: 0,
				bottom: 56,
				display: 'flex',
				justifyContent: 'center',
				padding: '0 160px',
				opacity,
			}}
		>
			<div
				style={{
					fontFamily: fonts.body,
					fontSize: 30,
					lineHeight: 1.4,
					color: '#FFFFFF',
					textAlign: 'center',
					background: 'rgba(10, 12, 16, 0.55)',
					padding: '10px 28px',
					borderRadius: 8,
				}}
			>
				{text}
			</div>
		</div>
	);
};
