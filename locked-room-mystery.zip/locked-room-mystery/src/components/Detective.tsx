import React from 'react';
import {useCurrentFrame, interpolate} from 'remotion';
import {colors} from '../theme';

type DetectivePose = 'walking' | 'kneeling' | 'standing-looking-down' | 'standing-alert';

type DetectiveProps = {
	x: number;
	y: number;
	scale?: number;
	pose?: DetectivePose;
	/** Mirror horizontally so she can face either direction. */
	faceLeft?: boolean;
};

/**
 * Original cartoon detective character — Inspector Maren Cole — built
 * as a flat-vector silhouette (trench coat, collar, fedora) so she
 * reads clearly at a glance against the lamplit study. Rendered as a
 * self-contained <g> so scenes can position/scale/mirror her freely.
 */
export const Detective: React.FC<DetectiveProps> = ({
	x,
	y,
	scale = 1,
	pose = 'standing-looking-down',
	faceLeft = false,
}) => {
	const frame = useCurrentFrame();

	// Gentle idle bob for any standing/kneeling pose.
	const idleBob = Math.sin(frame / 14) * 3;

	// Walk-cycle leg/arm swing, only used in 'walking' pose.
	const walkSwing = Math.sin(frame / 5) * 18;
	const walkBob = Math.abs(Math.sin(frame / 5)) * 6;

	const headTilt =
		pose === 'standing-looking-down'
			? interpolate(frame % 90, [0, 45, 90], [0, 6, 0])
			: 0;

	const kneeling = pose === 'kneeling';

	return (
		<g
			transform={`translate(${x}, ${y}) scale(${(faceLeft ? -1 : 1) * scale}, ${scale})`}
		>
			<g transform={`translate(0, ${pose === 'walking' ? -walkBob : -idleBob})`}>
				{/* Shadow */}
				<ellipse cx="0" cy="8" rx="46" ry="12" fill={colors.black} opacity={0.35} />

				{kneeling ? (
					<g transform="translate(0, -40)">
						{/* Kneeling coat */}
						<path
							d="M -40 0 Q -46 -70 -20 -110 L 20 -110 Q 46 -70 40 0 Q 20 20 0 20 Q -20 20 -40 0 Z"
							fill={colors.ink}
						/>
						{/* Back leg folded */}
						<rect x="-10" y="-10" width="24" height="26" rx="8" fill={colors.inkSoft} />
						{/* Head */}
						<g transform="translate(0, -128) rotate(14)">
							<circle cx="0" cy="0" r="30" fill={colors.paper} />
							<path
								d="M -34 -6 Q -34 -42 0 -42 Q 34 -42 34 -6 Q 34 -16 0 -16 Q -34 -16 -34 -6 Z"
								fill={colors.ink}
							/>
							<rect x="-38" y="-14" width="76" height="12" rx="4" fill={colors.ink} />
						</g>
					</g>
				) : (
					<g>
						{/* Coat / torso */}
						<path
							d="M -42 -10 Q -50 -120 -24 -210 L 24 -210 Q 50 -120 42 -10 Q 20 6 0 6 Q -20 6 -42 -10 Z"
							fill={colors.ink}
						/>
						{/* Belt */}
						<rect x="-34" y="-96" width="68" height="10" fill={colors.inkSoft} />

						{/* Back arm */}
						<rect
							x="-46"
							y="-190"
							width="16"
							height="92"
							rx="8"
							fill={colors.ink}
							transform={
								pose === 'walking'
									? `rotate(${-walkSwing} -38 -190)`
									: 'rotate(8 -38 -190)'
							}
						/>

						{/* Legs */}
						<rect
							x="-24"
							y="-14"
							width="20"
							height="100"
							rx="8"
							fill={colors.inkSoft}
							transform={
								pose === 'walking' ? `rotate(${walkSwing} -14 -14)` : undefined
							}
						/>
						<rect
							x="4"
							y="-14"
							width="20"
							height="100"
							rx="8"
							fill={colors.inkSoft}
							transform={
								pose === 'walking' ? `rotate(${-walkSwing} 14 -14)` : undefined
							}
						/>

						{/* Front arm */}
						<rect
							x="30"
							y="-190"
							width="16"
							height="92"
							rx="8"
							fill={colors.ink}
							transform={
								pose === 'walking'
									? `rotate(${walkSwing} 38 -190)`
									: 'rotate(-6 38 -190)'
							}
						/>

						{/* Head */}
						<g transform={`translate(0, -228) rotate(${headTilt})`}>
							<circle cx="0" cy="0" r="32" fill={colors.paper} />
							{/* Fedora */}
							<path
								d="M -38 -8 Q -38 -46 0 -46 Q 38 -46 38 -8 Q 38 -20 0 -20 Q -38 -20 -38 -8 Z"
								fill={colors.ink}
							/>
							<rect x="-42" y="-16" width="84" height="13" rx="5" fill={colors.ink} />
							{/* Collar */}
							<path d="M -18 20 L 0 34 L 18 20 L 18 34 L -18 34 Z" fill={colors.ink} />
						</g>
					</g>
				)}
			</g>
		</g>
	);
};
