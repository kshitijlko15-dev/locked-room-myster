import React from 'react';
import {useCurrentFrame} from 'remotion';
import {colors} from '../theme';

type FishPhotographProps = {
	x: number;
	y: number;
	scale?: number;
};

/**
 * A small framed photograph — a single stylized fish rendered as flat
 * line-art on parchment — propped against the bookshelf. A faint
 * shimmer drifts across it like light catching old photo paper.
 */
export const FishPhotograph: React.FC<FishPhotographProps> = ({
	x,
	y,
	scale = 1,
}) => {
	const frame = useCurrentFrame();
	const shimmer = (Math.sin(frame / 25) + 1) / 2; // 0..1

	return (
		<g transform={`translate(${x}, ${y}) scale(${scale})`}>
			<ellipse cx="0" cy="130" rx="110" ry="16" fill={colors.black} opacity={0.3} />
			{/* Frame, leaning slightly */}
			<g transform="rotate(-4)">
				<rect
					x="-110"
					y="-140"
					width="220"
					height="270"
					rx="6"
					fill={colors.woodDark}
				/>
				<rect
					x="-92"
					y="-122"
					width="184"
					height="234"
					fill={colors.paper}
				/>
				{/* Fish line-art */}
				<g transform="translate(0, -10)">
					<path
						d="M -60 0 Q -20 -40 50 0 Q -20 40 -60 0 Z"
						fill="none"
						stroke={colors.inkSoft}
						strokeWidth={4}
					/>
					<path
						d="M 50 0 L 78 -22 L 78 22 Z"
						fill="none"
						stroke={colors.inkSoft}
						strokeWidth={4}
						strokeLinejoin="round"
					/>
					<circle cx="-38" cy="-4" r="4" fill={colors.inkSoft} />
					<path
						d="M -20 -10 Q 0 -18 20 -10"
						fill="none"
						stroke={colors.inkSoft}
						strokeWidth={3}
					/>
					<path
						d="M -20 10 Q 0 18 20 10"
						fill="none"
						stroke={colors.inkSoft}
						strokeWidth={3}
					/>
				</g>
				{/* Shimmer */}
				<rect
					x="-92"
					y="-122"
					width="184"
					height="234"
					fill={colors.waterHighlight}
					opacity={shimmer * 0.08}
				/>
			</g>
		</g>
	);
};
