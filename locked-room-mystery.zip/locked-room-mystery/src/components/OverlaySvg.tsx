import React from 'react';

/**
 * Full-frame SVG overlay sharing the same 0 0 1920 1080 coordinate
 * space as StudyBackground's own internal <svg>, so characters and
 * props passed as children line up exactly with the room beneath
 * them. Use this to layer <Detective>, <BrokenBowl>, <WaterPuddle>,
 * or <FishPhotograph> on top of <StudyBackground>.
 */
export const OverlaySvg: React.FC<{children: React.ReactNode}> = ({
	children,
}) => (
	<svg
		viewBox="0 0 1920 1080"
		width="100%"
		height="100%"
		style={{position: 'absolute', top: 0, left: 0}}
	>
		{children}
	</svg>
);
