import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {colors} from '../theme';

type StudyBackgroundProps = {
	/** 0-1, how strongly the warm lamp glow washes the room (for mood per-scene). */
	lampIntensity?: number;
	/** Render the desk/bowl/puddle props, or keep them hidden for the establishing shot. */
	showDeskProps?: boolean;
	children?: React.ReactNode;
};

/**
 * The single reusable set for the whole short: a book-lined study at
 * night, lit by one desk lamp and the grey wash of a rainy window.
 * Built entirely from flat SVG shapes so it is original art, not a
 * reference to anything existing.
 */
export const StudyBackground: React.FC<StudyBackgroundProps> = ({
	lampIntensity = 1,
	showDeskProps = true,
	children,
}) => {
	const frame = useCurrentFrame();

	const rainOffset = (frame * 9) % 60;

	return (
		<AbsoluteFill style={{backgroundColor: colors.night}}>
			<svg
				viewBox="0 0 1920 1080"
				width="100%"
				height="100%"
				preserveAspectRatio="xMidYMid slice"
			>
				<defs>
					<radialGradient id="lampRadial" cx="50%" cy="35%" r="65%">
						<stop
							offset="0%"
							stopColor={colors.lampGlowSoft}
							stopOpacity={0.55 * lampIntensity}
						/>
						<stop
							offset="45%"
							stopColor={colors.lampGlow}
							stopOpacity={0.22 * lampIntensity}
						/>
						<stop offset="100%" stopColor={colors.lampGlow} stopOpacity={0} />
					</radialGradient>
					<linearGradient id="wallGradient" x1="0" y1="0" x2="0" y2="1">
						<stop offset="0%" stopColor={colors.studyWall} />
						<stop offset="100%" stopColor={colors.studyWallShadow} />
					</linearGradient>
					<linearGradient id="floorGradient" x1="0" y1="0" x2="0" y2="1">
						<stop offset="0%" stopColor={colors.floor} />
						<stop offset="100%" stopColor={colors.night} />
					</linearGradient>
					<clipPath id="windowClip">
						<rect x="1180" y="90" width="520" height="430" rx="6" />
					</clipPath>
				</defs>

				{/* Wall */}
				<rect x="0" y="0" width="1920" height="760" fill="url(#wallGradient)" />
				{/* Floor */}
				<rect x="0" y="760" width="1920" height="320" fill="url(#floorGradient)" />

				{/* Wainscoting line */}
				<rect x="0" y="700" width="1920" height="10" fill={colors.woodDark} opacity={0.5} />

				{/* ---- Window, back-right ---- */}
				<rect
					x="1160"
					y="70"
					width="560"
					height="470"
					rx="10"
					fill={colors.woodDark}
				/>
				<rect x="1180" y="90" width="520" height="430" rx="6" fill={colors.moonBlue} />
				<g clipPath="url(#windowClip)">
					<rect x="1180" y="90" width="520" height="430" fill={colors.moonBlue} />
					{/* Rain streaks, looping */}
					{Array.from({length: 14}).map((_, i) => {
						const x = 1190 + i * 38;
						const y = ((i * 53 + rainOffset * 8) % 470) - 40;
						return (
							<line
								key={i}
								x1={x}
								y1={y}
								x2={x - 14}
								y2={y + 60}
								stroke={colors.moonBlueSoft}
								strokeWidth={2}
								opacity={0.45}
								strokeLinecap="round"
							/>
						);
					})}
				</g>
				{/* Window mullions */}
				<rect x="1434" y="90" width="12" height="430" fill={colors.woodDark} />
				<rect x="1180" y="300" width="520" height="12" fill={colors.woodDark} />
				<rect
					x="1160"
					y="70"
					width="560"
					height="470"
					rx="10"
					fill="none"
					stroke={colors.woodDark}
					strokeWidth={10}
				/>

				{/* ---- Bookshelf, back-left ---- */}
				<rect x="120" y="120" width="620" height="580" rx="8" fill={colors.woodDark} />
				<rect x="150" y="150" width="560" height="520" fill={colors.wood} />
				{Array.from({length: 4}).map((_, shelfIndex) => (
					<g key={shelfIndex}>
						<rect
							x="150"
							y={190 + shelfIndex * 128}
							width="560"
							height="10"
							fill={colors.woodDark}
						/>
						{Array.from({length: 11}).map((_, bookIndex) => {
							const bookColors = [
								colors.rug,
								colors.moonBlue,
								colors.lampGlow,
								colors.studyWall,
								colors.paperShadow,
							];
							const h = 70 + ((bookIndex * 7 + shelfIndex * 5) % 28);
							const w = 24 + ((bookIndex * 3) % 10);
							return (
								<rect
									key={bookIndex}
									x={168 + bookIndex * 48}
									y={200 + shelfIndex * 128 - h}
									width={w}
									height={h}
									fill={bookColors[(bookIndex + shelfIndex) % bookColors.length]}
									opacity={0.9}
								/>
							);
						})}
					</g>
				))}

				{/* ---- Rug ---- */}
				<ellipse cx="960" cy="920" rx="480" ry="110" fill={colors.rugShadow} />
				<ellipse cx="960" cy="905" rx="430" ry="92" fill={colors.rug} />
				<ellipse
					cx="960"
					cy="905"
					rx="330"
					ry="68"
					fill="none"
					stroke={colors.lampGlow}
					strokeOpacity={0.25}
					strokeWidth={4}
				/>

				{/* ---- Desk, foreground-center ---- */}
				{showDeskProps && (
					<g>
						<rect x="700" y="760" width="520" height="24" fill={colors.woodDark} />
						<rect x="720" y="784" width="40" height="190" fill={colors.wood} />
						<rect x="1160" y="784" width="40" height="190" fill={colors.wood} />
						<rect x="680" y="740" width="560" height="30" rx="4" fill={colors.wood} />

						{/* Desk lamp */}
						<circle cx="1050" cy="640" r="150" fill="url(#lampRadial)" />
						<rect x="1040" y="700" width="10" height="40" fill={colors.woodDark} />
						<path
							d="M 1000 740 L 1100 740 L 1080 700 L 1020 700 Z"
							fill={colors.lampGlow}
							opacity={0.9}
						/>
						<rect x="1030" y="738" width="40" height="8" fill={colors.woodDark} />
					</g>
				)}

				{/* Ambient vignette */}
				<rect x="0" y="0" width="1920" height="1080" fill="black" opacity={0.08} />
			</svg>

			{/* Scene-specific props/characters render on top */}
			{children}
		</AbsoluteFill>
	);
};
