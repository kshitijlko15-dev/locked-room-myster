import React from 'react';
import {useCurrentFrame, interpolate} from 'remotion';
import {colors, fonts} from '../theme';

type TitleCardProps = {
	text: string;
	/** Local frame (within the parent scene) at which the card should start appearing. */
	appearAtFrame: number;
};

export const TitleCard: React.FC<TitleCardProps> = ({text, appearAtFrame}) => {
	const frame = useCurrentFrame();
	const opacity = interpolate(
		frame,
		[appearAtFrame, appearAtFrame + 20],
		[0, 1],
		{extrapolateLeft: 'clamp', extrapolateRight: 'clamp'}
	);

	return (
		<div
			style={{
				position: 'absolute',
				bottom: 90,
				width: '100%',
				textAlign: 'center',
				opacity,
			}}
		>
			<span
				style={{
					fontFamily: fonts.display,
					fontStyle: 'italic',
					fontSize: 46,
					color: colors.paper,
					letterSpacing: 2,
					textShadow: '0 2px 16px rgba(0,0,0,0.6)',
				}}
			>
				{text}
			</span>
		</div>
	);
};
