import React from 'react';
import {useCurrentFrame} from 'remotion';
import {colors} from '../theme';

type WaterPuddleProps = {
	x: number;
	y: number;
	scale?: number;
};

/**
 * A puddle on the study floor, reflecting the desk lamp, with two
 * ripple rings that continuously expand and fade — as if something
 * disturbed it moments ago.
 */
export const WaterPuddle: React.FC<WaterPuddleProps> = ({x, y, scale = 1}) => {
	const frame = useCurrentFrame();

	const ripple = (offset: number) => {
		const t = (frame + offset) % 70;
		const r = (t / 70) * 95;
		const opacity = Math.max(0, 1 - t / 70) * 0.5;
		return {r, opacity};
	};

	const ripple1 = ripple(0);
	const ripple2 = ripple(35);

	return (
		<g transform={`translate(${x}, ${y}) scale(${scale})`}>
			<ellipse cx="0" cy="0" rx="150" ry="52" fill={colors.waterDeep} opacity={0.9} />
			<ellipse cx="0" cy="0" rx="150" ry="52" fill={colors.water} opacity={0.35} />
			<ellipse
				cx="-20"
				cy="-8"
				rx="60"
				ry="18"
				fill={colors.waterHighlight}
				opacity={0.4}
			/>
			<ellipse
				cx="0"
				cy="0"
				rx={ripple1.r}
				ry={ripple1.r * 0.34}
				fill="none"
				stroke={colors.waterHighlight}
				strokeWidth={2}
				opacity={ripple1.opacity}
			/>
			<ellipse
				cx="0"
				cy="0"
				rx={ripple2.r}
				ry={ripple2.r * 0.34}
				fill="none"
				stroke={colors.waterHighlight}
				strokeWidth={2}
				opacity={ripple2.opacity}
			/>
			<ellipse
				cx="0"
				cy="0"
				rx="150"
				ry="52"
				fill="none"
				stroke={colors.night}
				strokeWidth={3}
				opacity={0.4}
			/>
		</g>
	);
};
