import {video} from './theme';

/**
 * ============================================================
 *  NARRATION — PLACEHOLDER SCRIPT
 * ============================================================
 * You asked to use "the narration you provided in this conversation,"
 * but no narration text actually came through on this request — so
 * the lines below are an original placeholder script written to fit
 * the title "The Locked Room Mystery" (noir tone, no solution
 * revealed) purely so the project has something real to sync to and
 * render end-to-end.
 *
 * TO SWAP IN YOUR REAL NARRATION:
 *   1. Replace the `text` field of each line below with your script,
 *      split into however many beats you like.
 *   2. Update `startSeconds` / `endSeconds` to match your recorded
 *      audio (open the file in any audio editor, or your phone's
 *      voice memo app, and read off the timestamps where each line
 *      begins/ends).
 *   3. If your narration's total length isn't 60s, see "Changing the
 *      total length" in README.md.
 *   4. Record/export your audio as public/audio/narration.mp3 — see
 *      public/audio/README.txt for exact instructions.
 *
 * Scene components read `durationInFrames` from here, so changing
 * the seconds below automatically re-times the whole video.
 */

export type NarrationLine = {
	id: string;
	text: string;
	startSeconds: number;
	endSeconds: number;
};

export const narrationLines: NarrationLine[] = [
	{
		id: 'establishing',
		text:
			'Rain tapped the window of No. 14 Pemberton Row, where Inspector Maren Cole had been called to a room that should have been impossible to enter.',
		startSeconds: 0,
		endSeconds: 10,
	},
	{
		id: 'detective-arrives',
		text:
			'The study door had been locked from the inside. No window forced, no footprints beyond the threshold — and yet something in the room had changed.',
		startSeconds: 10,
		endSeconds: 20,
	},
	{
		id: 'broken-bowl',
		text:
			'Near the desk lay a porcelain bowl, shattered into a dozen pieces, as if it had simply let go.',
		startSeconds: 20,
		endSeconds: 30,
	},
	{
		id: 'water-puddle',
		text:
			'Beside it, a puddle caught the lamplight — though no pipe ran anywhere near that corner of the room.',
		startSeconds: 30,
		endSeconds: 40,
	},
	{
		id: 'fish-photograph',
		text:
			"And propped against the shelf, turned to face the desk, sat a photograph of a single fish — one that hadn't been there yesterday.",
		startSeconds: 40,
		endSeconds: 50,
	},
	{
		id: 'cliffhanger',
		text:
			'Inspector Cole knelt beside the puddle and narrowed her eyes. Three clues. No suspects. And a room that kept its secrets closer than its door.',
		startSeconds: 50,
		endSeconds: 60,
	},
];

// Derived frame-accurate timing, used by Root.tsx and MysteryVideo.tsx.
export const sceneTimings = narrationLines.map((line) => {
	const from = Math.round(line.startSeconds * video.fps);
	const durationInFrames = Math.round(
		(line.endSeconds - line.startSeconds) * video.fps
	);
	return {id: line.id, from, durationInFrames, text: line.text};
});

export const totalDurationInFrames = sceneTimings.reduce(
	(sum, s) => sum + s.durationInFrames,
	0
);
