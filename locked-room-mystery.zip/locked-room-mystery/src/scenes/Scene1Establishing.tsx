import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {StudyBackground} from '../components/StudyBackground';
import {Camera} from '../components/Camera';
import {Caption} from '../components/Caption';
import {getEdgeFade} from '../utils';

type Props = {
	durationInFrames: number;
	captionText: string;
};

export const Scene1Establishing: React.FC<Props> = ({
	durationInFrames,
	captionText,
}) => {
	const frame = useCurrentFrame();
	const opacity = getEdgeFade(frame, durationInFrames, 24);

	return (
		<AbsoluteFill style={{opacity}}>
			{/* Slow push-in from a wide view of the whole study, setting mood
			    before any character or clue appears. */}
			<Camera durationInFrames={durationInFrames} fromScale={1} toScale={1.12}>
				<StudyBackground lampIntensity={0.8} showDeskProps />
			</Camera>
			<Caption text={captionText} opacity={opacity} />
		</AbsoluteFill>
	);
};
