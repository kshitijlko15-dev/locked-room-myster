import React from 'react';
import {AbsoluteFill, useCurrentFrame, interpolate} from 'remotion';
import {StudyBackground} from '../components/StudyBackground';
import {Detective} from '../components/Detective';
import {OverlaySvg} from '../components/OverlaySvg';
import {Camera} from '../components/Camera';
import {Caption} from '../components/Caption';
import {getEdgeFade} from '../utils';

type Props = {
	durationInFrames: number;
	captionText: string;
};

export const Scene2DetectiveArrives: React.FC<Props> = ({
	durationInFrames,
	captionText,
}) => {
	const frame = useCurrentFrame();
	const opacity = getEdgeFade(frame, durationInFrames, 24);

	// Walks in from the left edge toward the desk, then settles.
	const walkProgress = interpolate(frame, [0, durationInFrames - 60], [0, 1], {
		extrapolateLeft: 'clamp',
		extrapolateRight: 'clamp',
	});
	const detectiveX = 260 + walkProgress * 520;
	const isWalking = walkProgress < 1;

	return (
		<AbsoluteFill style={{opacity}}>
			<Camera
				durationInFrames={durationInFrames}
				fromScale={1.05}
				toScale={1}
				fromXPercent={2}
				toXPercent={0}
			>
				<StudyBackground lampIntensity={0.9} showDeskProps>
					<OverlaySvg>
						<Detective
							x={detectiveX}
							y={960}
							scale={1.15}
							pose={isWalking ? 'walking' : 'standing-looking-down'}
						/>
					</OverlaySvg>
				</StudyBackground>
			</Camera>
			<Caption text={captionText} opacity={opacity} />
		</AbsoluteFill>
	);
};
