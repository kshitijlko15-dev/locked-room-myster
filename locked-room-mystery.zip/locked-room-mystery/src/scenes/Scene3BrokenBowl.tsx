import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {StudyBackground} from '../components/StudyBackground';
import {Detective} from '../components/Detective';
import {BrokenBowl} from '../components/BrokenBowl';
import {OverlaySvg} from '../components/OverlaySvg';
import {Camera} from '../components/Camera';
import {Caption} from '../components/Caption';
import {getEdgeFade} from '../utils';

type Props = {
	durationInFrames: number;
	captionText: string;
};

export const Scene3BrokenBowl: React.FC<Props> = ({
	durationInFrames,
	captionText,
}) => {
	const frame = useCurrentFrame();
	const opacity = getEdgeFade(frame, durationInFrames, 24);

	return (
		<AbsoluteFill style={{opacity}}>
			{/* Dolly down and in toward the shards on the floor. */}
			<Camera
				durationInFrames={durationInFrames}
				fromScale={1}
				toScale={1.5}
				fromYPercent={0}
				toYPercent={-10}
			>
				<StudyBackground lampIntensity={1} showDeskProps>
					<OverlaySvg>
						<Detective x={1320} y={960} scale={1.1} pose="standing-looking-down" />
						<BrokenBowl x={840} y={940} scale={1.1} />
					</OverlaySvg>
				</StudyBackground>
			</Camera>
			<Caption text={captionText} opacity={opacity} />
		</AbsoluteFill>
	);
};
