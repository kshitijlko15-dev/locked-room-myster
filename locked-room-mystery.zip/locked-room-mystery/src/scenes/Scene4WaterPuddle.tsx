import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {StudyBackground} from '../components/StudyBackground';
import {Detective} from '../components/Detective';
import {BrokenBowl} from '../components/BrokenBowl';
import {WaterPuddle} from '../components/WaterPuddle';
import {OverlaySvg} from '../components/OverlaySvg';
import {Camera} from '../components/Camera';
import {Caption} from '../components/Caption';
import {getEdgeFade} from '../utils';

type Props = {
	durationInFrames: number;
	captionText: string;
};

export const Scene4WaterPuddle: React.FC<Props> = ({
	durationInFrames,
	captionText,
}) => {
	const frame = useCurrentFrame();
	const opacity = getEdgeFade(frame, durationInFrames, 24);

	return (
		<AbsoluteFill style={{opacity}}>
			{/* Tilt/pan sideways from the bowl toward the puddle beside it. */}
			<Camera
				durationInFrames={durationInFrames}
				fromScale={1.3}
				toScale={1.45}
				fromXPercent={6}
				toXPercent={-4}
			>
				<StudyBackground lampIntensity={1} showDeskProps>
					<OverlaySvg>
						<Detective x={1320} y={960} scale={1.1} pose="kneeling" />
						<BrokenBowl x={840} y={940} scale={1.05} />
						<WaterPuddle x={1060} y={1000} scale={1.1} />
					</OverlaySvg>
				</StudyBackground>
			</Camera>
			<Caption text={captionText} opacity={opacity} />
		</AbsoluteFill>
	);
};
