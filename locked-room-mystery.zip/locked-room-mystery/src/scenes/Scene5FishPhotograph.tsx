import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {StudyBackground} from '../components/StudyBackground';
import {FishPhotograph} from '../components/FishPhotograph';
import {OverlaySvg} from '../components/OverlaySvg';
import {Camera} from '../components/Camera';
import {Caption} from '../components/Caption';
import {getEdgeFade} from '../utils';

type Props = {
	durationInFrames: number;
	captionText: string;
};

export const Scene5FishPhotograph: React.FC<Props> = ({
	durationInFrames,
	captionText,
}) => {
	const frame = useCurrentFrame();
	const opacity = getEdgeFade(frame, durationInFrames, 24);

	return (
		<AbsoluteFill style={{opacity}}>
			{/* Pan left to the bookshelf and push into the photograph. */}
			<Camera
				durationInFrames={durationInFrames}
				fromScale={1.1}
				toScale={1.6}
				fromXPercent={-18}
				toXPercent={-28}
				fromYPercent={-8}
				toYPercent={-14}
			>
				<StudyBackground lampIntensity={0.85} showDeskProps={false}>
					<OverlaySvg>
						<FishPhotograph x={420} y={560} scale={1.3} />
					</OverlaySvg>
				</StudyBackground>
			</Camera>
			<Caption text={captionText} opacity={opacity} />
		</AbsoluteFill>
	);
};
