import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {StudyBackground} from '../components/StudyBackground';
import {Detective} from '../components/Detective';
import {BrokenBowl} from '../components/BrokenBowl';
import {WaterPuddle} from '../components/WaterPuddle';
import {OverlaySvg} from '../components/OverlaySvg';
import {Camera} from '../components/Camera';
import {Caption} from '../components/Caption';
import {TitleCard} from '../components/TitleCard';
import {getEdgeFade} from '../utils';

type Props = {
	durationInFrames: number;
	captionText: string;
};

/**
 * Deliberately does NOT show or state who caused the three clues —
 * ends on the detective's reaction, not an answer.
 */
export const Scene6Cliffhanger: React.FC<Props> = ({
	durationInFrames,
	captionText,
}) => {
	const frame = useCurrentFrame();
	const opacity = getEdgeFade(frame, durationInFrames, 30);

	return (
		<AbsoluteFill style={{opacity}}>
			{/* Slow pull back from the puddle to re-reveal the whole scene,
			    ending the short on the room, not an answer. */}
			<Camera
				durationInFrames={durationInFrames}
				fromScale={1.35}
				toScale={1}
				fromXPercent={-4}
				toXPercent={0}
				fromYPercent={-8}
				toYPercent={0}
			>
				<StudyBackground lampIntensity={1} showDeskProps>
					<OverlaySvg>
						<Detective x={1320} y={960} scale={1.1} pose="kneeling" />
						<BrokenBowl x={840} y={940} scale={1.05} />
						<WaterPuddle x={1060} y={1000} scale={1.1} />
					</OverlaySvg>
				</StudyBackground>
			</Camera>
			<TitleCard text="To be continued…" appearAtFrame={durationInFrames - 70} />
			<Caption text={captionText} opacity={opacity} />
		</AbsoluteFill>
	);
};
