// Visual identity for "The Locked Room Mystery"
//
// Style chosen for this piece: flat-vector noir cartoon.
// A locked-room mystery lives on mood and restraint — rain-streaked
// windows, a single lamp, long shadows — so the palette favors deep,
// desaturated blues and charcoal with one warm amber accent (the
// desk lamp) and one cool accent (moonlight through the window).
// Flat vector shapes (no heavy outlines, soft gradients only where
// light sources justify them) keep the characters and props legible
// at a glance, which matters because every scene is on screen for
// only ~10 seconds.

export const colors = {
  night: '#12151C',
  studyWall: '#232B38',
  studyWallShadow: '#191F29',
  floor: '#1C222C',
  wood: '#4B3625',
  woodDark: '#2E2013',
  rug: '#5C2A34',
  rugShadow: '#431D25',
  lampGlow: '#E8A33D',
  lampGlowSoft: '#F6CE8B',
  moonBlue: '#3E5872',
  moonBlueSoft: '#6A85A0',
  paper: '#EDE3CF',
  paperShadow: '#C9BB9D',
  ink: '#0E1116',
  inkSoft: '#1B2027',
  water: '#7FB3D5',
  waterDeep: '#3E7A9E',
  waterHighlight: '#CFEAF7',
  fog: 'rgba(62, 88, 114, 0.18)',
  black: '#000000',
} as const;

export const fonts = {
  display: "'Georgia', 'Iowan Old Style', 'Times New Roman', serif",
  body: "'Helvetica Neue', Arial, sans-serif",
} as const;

export const video = {
  width: 1920,
  height: 1080,
  fps: 30,
  durationInSeconds: 60,
} as const;

export const video_durationInFrames = video.fps * video.durationInSeconds;
