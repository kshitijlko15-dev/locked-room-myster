import {interpolate, Easing} from 'remotion';

/**
 * Opacity curve that fades a scene in from 0, holds at 1, then fades
 * out near the end of its own duration — used to crossfade between
 * Sequences without needing an extra transitions package.
 */
export const getEdgeFade = (
	localFrame: number,
	durationInFrames: number,
	fadeFrames: number = 18
): number => {
	const fadeIn = interpolate(localFrame, [0, fadeFrames], [0, 1], {
		extrapolateLeft: 'clamp',
		extrapolateRight: 'clamp',
	});
	const fadeOut = interpolate(
		localFrame,
		[durationInFrames - fadeFrames, durationInFrames],
		[1, 0],
		{
			extrapolateLeft: 'clamp',
			extrapolateRight: 'clamp',
		}
	);
	return Math.min(fadeIn, fadeOut);
};

export type CameraMoveConfig = {
	fromScale?: number;
	toScale?: number;
	fromXPercent?: number;
	toXPercent?: number;
	fromYPercent?: number;
	toYPercent?: number;
};

/**
 * Returns a CSS transform string for a slow, cinematic Ken Burns style
 * push/pan, eased so the motion starts and ends gently.
 */
export const getCameraTransform = (
	localFrame: number,
	durationInFrames: number,
	config: CameraMoveConfig = {}
): string => {
	const {
		fromScale = 1,
		toScale = 1.08,
		fromXPercent = 0,
		toXPercent = 0,
		fromYPercent = 0,
		toYPercent = 0,
	} = config;

	const progress = interpolate(localFrame, [0, durationInFrames], [0, 1], {
		extrapolateLeft: 'clamp',
		extrapolateRight: 'clamp',
		easing: Easing.bezier(0.33, 0, 0.2, 1),
	});

	const scale = fromScale + (toScale - fromScale) * progress;
	const x = fromXPercent + (toXPercent - fromXPercent) * progress;
	const y = fromYPercent + (toYPercent - fromYPercent) * progress;

	return `scale(${scale}) translate(${x}%, ${y}%)`;
};

/** Gentle sine-based wobble, handy for idle motion (rain, ripples, breathing). */
export const wobble = (frame: number, speed: number, amplitude: number): number =>
	Math.sin(frame * speed) * amplitude;
